/****************************************************************************/
/*!
\author Judy Cheng
\par    email: j.cheng\@digipen.edu (Optional)
\par    Course: GAM 200
\date   xx/xx/xx (Optional)
\brief

A sound emitter component.


Copyright: All content @ 2014 DigiPen (USA) Corporation, all rights reserved.

*/
/****************************************************************************/
#include "Precompiled.h"
#include "SoundEmitter.h"
#include "Engine.h"

SoundEmitter::SoundEmitter(IEntity *Owner) : 
IComponent(Component_Type::CT_SoundEmitter, Owner), playSoundOnStart(false)
{
}

bool SoundEmitter::Initialize()
{
  //Get a pointer to the main sound system
  m_manager = ENGINE->m_Sound;

  if (playSoundOnStart)
    PlayEvent(startSound);

  return true;
}

SoundEmitter::~SoundEmitter()
{
  if (playSoundOnStart)
    StopEvent(startSound);
}

void SoundEmitter::PlayEvent(std::string name)
{
  m_manager->PlayEvent(name);
}

void SoundEmitter::StopEvent(std::string name)
{
  m_manager->StopSound(name);
}

void SoundEmitter::SetPause(bool pause, std::string name)
{
  if (pause == true)
  {
    m_manager->Pause(true, name);
  }
  else
  {
    m_manager->Pause(false, name);
  }
}

void SoundEmitter::SetVolume(float vol, std::string name)
{
  m_manager->Volume(vol, name);
}

void SoundEmitter::Update(float dt)
{
}

void SoundEmitter::Release()
{
}