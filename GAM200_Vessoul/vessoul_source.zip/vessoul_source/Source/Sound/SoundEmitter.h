/****************************************************************************/
/*!
\author Judy Cheng
\par    email: j.cheng\@digipen.edu (Optional)
\par    Course: GAM 200
\date   xx/xx/xx (Optional)
\brief

A sound emitter component header


Copyright: All content @ 2014 DigiPen (USA) Corporation, all rights reserved.

*/
/****************************************************************************/
#pragma once
#include "Precompiled.h"
#include "SoundManager.h"

class SoundEmitter;

class SoundEmitter : public IComponent
{
public:
  SoundEmitter() {};
  SoundEmitter(IEntity *Owner);
  ~SoundEmitter();

  bool Initialize() override;
  void Update(float dt) override;
  void Release() override;

  void PlayEvent(std::string name);
  void StopEvent(std::string name);
  void SetPause(bool pause, std::string name);
  void SetVolume(float vol, std::string name);

  //Set in editor (optional, see segment in FactoryManager)
  bool playSoundOnStart;
  std::string startSound;
private:
  // Core
  SoundManager* m_manager;

  
};