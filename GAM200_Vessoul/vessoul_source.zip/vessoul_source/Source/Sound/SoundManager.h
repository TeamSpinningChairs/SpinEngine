/****************************************************************************/
/*!
\author Esteban Maldonado & Judy Cheng
\par    email: esteban.maldonado@digipen.edu
\par    Course: GAM 200
\brief

Class interface for the Sound system.

Copyright: All content @ 2014 DigiPen (USA) Corporation, all rights reserved.

*/
/****************************************************************************/
#pragma once
#include "Precompiled.h"

typedef FMOD::Studio::System* SoundSystem;
typedef FMOD::Studio::Bank* SoundBank;
typedef std::unordered_map<std::string, FMOD::Studio::EventInstance *> SoundCollection;
typedef std::unordered_map<std::string, FMOD::Studio::EventInstance *>::iterator SoundCollIter;

class SoundManager : public ISystem
{
public:
  SoundManager();
  ~SoundManager();

  bool Initialize() override;
  void Update(float dt) override;
  void Shutdown() override;

  bool PlayEvent(std::string name);
  bool StopSound(std::string name);
  void Pause(bool pause, std::string name);
  void Volume(float vol, std::string name);
  void PauseAll(void);
  void StopAll(void);
  void ResumeAll(void);

private:
  SoundSystem m_MainSoundSystem;
  SoundBank m_MasterBank; // Bank of sounds tied to a string
  SoundBank m_AmbienceBank; // Bank of Ambience sounds tied to a string
  SoundBank m_MusicBank; // Bank of music sounds tied to a string
  SoundBank m_StringsBank; // Strings of all events
  SoundCollection m_LoopingSounds;

};

extern SoundManager *sound;