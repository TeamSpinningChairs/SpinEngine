/****************************************************************************/
/*!
    \file   NewMessageSystem.cpp
    \author Steven Gallwas
    \par    email: s.gallwas\@digipen.edu
    \par    Course: GAM 200
    \date   9/16/14
    \brief  
        This file contains the implementation for the base messaging system.

    Copyright: All content @ 2014 DigiPen (USA) Corporation, all rights reserved.

*/
/****************************************************************************/
#include "Precompiled.h"
#include "InputHandler.h"
#include "DebugMessages.h"
#include "Core\NewMessageSystem.h"
#include "InputPlayback.h"
#include "InputRecord.h"

InputMessage::InputMessage(void)
{
	this->time = 0.0f;
	this->Controller_Num = 0;
	this->KeyDown = false;
	this->KeyPressed = false;
	this->KeyReleased = false;
	this->Key_Hold_Time = 0;
	this->leftStick.first = 0.0f;
	this->leftStick.second = 0.0f;
	this->MessageType = MESSAGE_INPUT;
	this->rightStick.first = 0.0f;
	this->rightStick.second = 0.0f;
}

Button_Status::Button_Status(void)
{
  ButtonDown = false;
  TimeHeld = 0;
}

Controller_Status::Controller_Status(void) : Buttons(ButtonCount), 
											 LeftStick(0,0), RightStick(0,0)
{
  RightTrigger = 0.0f;
  LeftTrigger = 0.0f;
}

/*************************************************************************/
/*!
  \brief
    Constructor for input handler
*/
/*************************************************************************/
InputHandler::InputHandler(void) : Active_Controllers(XUSER_MAX_COUNT),
									Controllers(XUSER_MAX_COUNT),
									Current_States(XUSER_MAX_COUNT),
									XInputDefines(ButtonCount),
                  playback(), recording()
{
  this->Controllers[0].ControllerNum = 0;
  this->Controllers[0].ControllerNum = 1;
  this->Controllers[0].ControllerNum = 2;
  this->Controllers[0].ControllerNum = 3;

  Active_Controllers[0] = false;
  Active_Controllers[1] = false;
  Active_Controllers[2] = false;
  Active_Controllers[3] = false;

  this->XInputDefines[BUTTONS_A] = XINPUT_GAMEPAD_A;
  this->XInputDefines[BUTTONS_X] = XINPUT_GAMEPAD_X;
  this->XInputDefines[BUTTONS_B] = XINPUT_GAMEPAD_B;
  this->XInputDefines[BUTTONS_Y] = XINPUT_GAMEPAD_Y;
  this->XInputDefines[BUTTONS_RIGHT_SHOULDER] = XINPUT_GAMEPAD_RIGHT_SHOULDER;
  this->XInputDefines[BUTTONS_LEFT_SHOULDER] = XINPUT_GAMEPAD_LEFT_SHOULDER;
  this->XInputDefines[BUTTONS_BACK] = XINPUT_GAMEPAD_BACK;
  this->XInputDefines[BUTTONS_START] = XINPUT_GAMEPAD_START;
  this->XInputDefines[DPAD_LEFT] = XINPUT_GAMEPAD_DPAD_LEFT;
  this->XInputDefines[DPAD_RIGHT] = XINPUT_GAMEPAD_DPAD_RIGHT;
  this->XInputDefines[DPAD_UP] = XINPUT_GAMEPAD_DPAD_UP;
  this->XInputDefines[DPAD_DOWN] = XINPUT_GAMEPAD_DPAD_DOWN;
  this->XInputDefines[LEFT_STICK] = XINPUT_GAMEPAD_LEFT_THUMB;
  this->XInputDefines[RIGHT_STICK] = XINPUT_GAMEPAD_RIGHT_THUMB;
  
  AutoPlay = false;
  ZeroMemory(&CurrentControls, sizeof(XINPUT_STATE));
  AutoTimer = AutoDelay;
}

/*************************************************************************/
/*!
  \brief
    set the GlobalSystem pointer to a new messagesystem. should only
    be called once
*/
/*************************************************************************/
void InputHandler::Update_Active_Controllers(void)
{
	if (AutoPlay)
	{
		if (AutoTimer >= AutoDelay)
		{
			// call function to generate random input
			GenerateRandomInput(this->CurrentControls.Gamepad);
			AutoTimer = 0.0f;
		}

		Current_States[0] = CurrentControls;
		return;
	}
	else if (*playback.enabled_)
	{
		XINPUT_STATE state;
		ZeroMemory(&state, sizeof(XINPUT_STATE));

		playback.GetNextInput(state.Gamepad);
		Current_States[0] = state;
		return;
	}

   // variable to track if a controller exits
  DWORD ControllerResult;    

  // check the status of four controllers
  for (DWORD i=0; i< XUSER_MAX_COUNT; i++)
  {
    // if the controller is active get its current state
	  if (this->Active_Controllers[i] == true)
	  {
		  XINPUT_STATE state;
		  ZeroMemory(&state, sizeof(XINPUT_STATE));

		  // get the state for the current controller
		  ControllerResult = XInputGetState(i, &state);	

      // store the current button imputs for the designated controller
      if(ControllerResult == ERROR_SUCCESS)
      {
        this->Current_States[i] = state;

		    if (*recording.enabled_)
		    {
			    recording.Record(state.Gamepad);
		    }
      }
    
    } // end of if check
  
  }   // end of for loop

}     // end of function

/*************************************************************************/
/*!
  \brief
    set the GlobalSystem pointer to a new messagesystem. should only
    be called once
*/
/*************************************************************************/
void InputHandler::Check_for_Controllers(void)
{
	if (*playback.enabled_ || AutoPlay)
	{
		this->Active_Controllers[0] = true;
		return;
	}

  // variable to track if a controller exists
  DWORD ControllerResult;    
  
  int ControllersActive = 0;

  // check the status of four controllers
  for (DWORD i=0; i< XUSER_MAX_COUNT; i++)
  {
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(XINPUT_STATE));

    // get the state for the current controller
    ControllerResult = XInputGetState(i, &state);

    // toggle the boolean flag in the list of controllers 
    //for the current controller if active
    if(ControllerResult == ERROR_SUCCESS)
    {
      ControllersActive++;
      this->Active_Controllers[i] = true;
      //OutputDebugString("\n\nController Connected\n\n");
    }
  }

  if(ControllersActive == 0)
  {
    //SendDebugMessage("No Controller Connected");
  }

  else
  {
    for(int i = 0; i < 4; i++)
    {
      std::cout<< Active_Controllers[i] << std::endl;
    }
  }

}

/*************************************************************************/
/*!
  \brief
    set the GlobalSystem pointer to a new messagesystem. should only
    be called once
*/
/*************************************************************************/
void InputHandler::Update_Controller_States(void)
{
  for(int i = 0; i < XUSER_MAX_COUNT; i++)
  {
    if(this->Active_Controllers[i] != true)
      continue;
    
    else
      this->UpdateSticks_and_Triggers(i);
  }

  for(int i = 0; i < ButtonCount; i++)
  {    
    this->UpdateButton(i);
  }
}

/*************************************************************************/
/*!
  \brief
    Updates the current state of a given button for all controllers.
    Called in the update function
  
  \param ButtonType
    the type of button to check.
  
*/
/*************************************************************************/
void InputHandler::UpdateSticks_and_Triggers(int ControllerNum)
{
  this->Controllers[ControllerNum].LeftStick.first = this->Current_States[ControllerNum].Gamepad.sThumbLX;
  this->Controllers[ControllerNum].LeftStick.second = this->Current_States[ControllerNum].Gamepad.sThumbLY;

  this->Controllers[ControllerNum].RightStick.first = this->Current_States[ControllerNum].Gamepad.sThumbRX;
  this->Controllers[ControllerNum].RightStick.second = this->Current_States[ControllerNum].Gamepad.sThumbRY;
}

/*************************************************************************/
/*!
  \brief
    Updates the current state of a given button for all controllers.
    Called in the update function
  
  \param ButtonType
    the type of button to check.
  
*/
/*************************************************************************/
void InputHandler::UpdateButton(int ButtonType)
{
  for(int i = 0; i < XUSER_MAX_COUNT; i++)
  {
    if(this->Active_Controllers[i] != true)
      continue;

	if (this->Current_States[i].Gamepad.wButtons & XInputDefines[ButtonType])
	{
		this->Controllers[i].Buttons[ButtonType].ButtonDown = true;
	}

	else
	{
		this->Controllers[i].Buttons[ButtonType].ButtonDown = false;
	}

	/*
      if(this->Controllers[i].Buttons[ButtonType].ButtonPressed == false)
        this->Controllers[i].Buttons[ButtonType].ButtonPressed = true;

      else if(this->Controllers[i].Buttons[ButtonType].ButtonDown == true)
      {  
        // increment how long the button has been down for
        this->Controllers[i].Buttons[ButtonType].TimeHeld += 1;
        this->Controllers[i].Buttons[ButtonType].ButtonDown = true;
      }
    }

    // if the button is not pressed, 
    else
    {
      this->Controllers[i].Buttons[ButtonType].ButtonPressed = false;
      this->Controllers[i].Buttons[ButtonType].ButtonDown = false;
      this->Controllers[i].Buttons[ButtonType].TimeHeld = 0;
    }
	*/
  }
}

/*************************************************************************/
/*!
  \brief
    Updates the current state of a given button for all controllers.
    Called in the update function
  
  \param ButtonType
    the type of button to check.
  
*/
/*************************************************************************/
void InputHandler::SendButtonMessages(float time)
{
	for (int i = 0; i < XUSER_MAX_COUNT; i++)
	{
		if (this->Active_Controllers[i] != true)
			continue;
		
		for (int j = 0; j < ButtonCount; j++)
		{
			InputMessage ButtonMessage;

			if (this->ButtonTriggered(i, j))
				ButtonMessage.KeyPressed = true;
			
			else if (this->ButtonDown(i, j))
				ButtonMessage.KeyDown = true;
			
			else if (this->ButtonReleased(i, j))
				ButtonMessage.KeyReleased = true;
			
			else
				continue;

			ButtonMessage.TriggeredKey = j;
			ButtonMessage.rightStick = this->Controllers[i].RightStick;
			ButtonMessage.leftStick = this->Controllers[i].LeftStick;
			ButtonMessage.time = time;
			GlobalSystem->MyDispatchMessage(&ButtonMessage);
		}
	
	}

  /*
  for(int i = 0; i < XUSER_MAX_COUNT; i++)
  {
    if(this->Active_Controllers[i] != true)
      continue;

      for(int j = 0; j < ButtonCount; j++)
      {
        if(this->Controllers[i].Buttons[j].ButtonPressed == true)
        {
          ButtonMessage.Controller_Num = i;

          ButtonMessage.TriggeredKey = j;

          if(this->Controllers[i].Buttons[j].ButtonDown == false)
            ButtonMessage.KeyPressed = true;
          
          else
          {
            ButtonMessage.KeyDown = true;
            ButtonMessage.Key_Hold_Time = this->Controllers[i].Buttons[j].TimeHeld;
          }
            ButtonMessage.rightStick = this->Controllers[i].RightStick;
            ButtonMessage.leftStick = this->Controllers[i].LeftStick;
            ButtonMessage.time = time;

          GlobalSystem->MyDispatchMessage(&ButtonMessage);
        }
      }
  }
  */
}

/*************************************************************************/
/*!
  \brief
    Updates the current state of a given button for all controllers.
    Called in the update function
  
  \param ButtonType
    the type of button to check.
  
*/
/*************************************************************************/
void InputHandler::Update(float dt)
{
	if (AutoPlay)
	{
		AutoTimer += dt;
	}

  this->Update_Controller_States();
  this->Update_Active_Controllers();
  this->SendButtonMessages(dt);
}

/*************************************************************************/
/*!
  \brief
    Updates the current state of a given button for all controllers.
    Called in the update function
  
  \param ButtonType
    the type of button to check.
  
*/
/*************************************************************************/
bool InputHandler::ButtonTriggered(int ControllerNum, int ButtonType)
{
  //check the button is currently down
  if(this->Current_States[ControllerNum].Gamepad.wButtons & XInputDefines[ButtonType])
  {  
    //check if the button was not down last frame
    if(this->Controllers[ControllerNum].Buttons[ButtonType].ButtonDown == false)
      return true;
  }
      return false;
}

/*************************************************************************/
/*!
  \brief
    Updates the current state of a given button for all controllers.
    Called in the update function
  
  \param ButtonType
    the type of button to check.
  
*/
/*************************************************************************/
bool InputHandler::ButtonDown(int ControllerNum, int ButtonType)
{
  if(this->Current_States[ControllerNum].Gamepad.wButtons & XInputDefines[ButtonType])
    return true;
  
  return false;
}

/*************************************************************************/
/*!
  \brief
    Updates the current state of a given button for all controllers.
    Called in the update function
  
  \param ButtonType
    the type of button to check.
  
*/
/*************************************************************************/
bool InputHandler::ButtonReleased(int ControllerNum, int ButtonType)
{
    //check the button is currently down return false if it is
	if (this->Current_States[ControllerNum].Gamepad.wButtons & XInputDefines[ButtonType])
	{
		return false;
	}
	    //check if the button was down last frame if so return true
		if(this->Controllers[ControllerNum].Buttons[ButtonType].ButtonDown == true)
			return true;

	// default return statement
      return false;
}

/*************************************************************************/
/*!
  \brief
    Updates the current state of a given button for all controllers.
    Called in the update function
  
  \param ButtonType
    the type of button to check.
  
*/
/*************************************************************************/
  bool InputHandler::Initialize()
  {
    playback.Initialize();
    recording.Initialize();
    
    XInputEnable(true);
    this->Check_for_Controllers();

    return true;
  }
	

/*************************************************************************/
/*!
\brief
	doesn't do anything right now
	
*/
/*************************************************************************/
void InputHandler::Shutdown()
{
return;
}

void InputHandler::NormalizeSticks(void)
{
  for(int i = 0; i < XUSER_MAX_COUNT; i++)
  {
    if(this->Active_Controllers[i] != true)
      continue;

	float LeftX = Current_States[i].Gamepad.sThumbLX;
	float LeftY = Current_States[i].Gamepad.sThumbLY;

	//determine how far the controller is pushed
	float magnitude = sqrt(LeftX*LeftX + LeftY*LeftY);

	//determine the direction the controller is pushed
	float normalizedLX = LeftX / magnitude;
	float normalizedLY = LeftY / magnitude;

	float normalizedMagnitude = 0;

	//check if the controller is outside a circular dead zone
	if (magnitude > XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE)
	{
		//clip the magnitude at its expected maximum value
		if (magnitude > 32767) magnitude = 32767;

		//adjust magnitude relative to the end of the dead zone
		magnitude -= XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE;

		//optionally normalize the magnitude with respect to its expected range
		//giving a magnitude value of 0.0 to 1.0
		normalizedMagnitude = magnitude / (32767 - XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE);
	}
	
	else //if the controller is in the deadzone zero out the magnitude
	{
		magnitude = 0.0;
		normalizedMagnitude = 0.0;
	}

	Current_States[i].Gamepad.sThumbLX = normalizedLX;
	Current_States[i].Gamepad.sThumbLY = normalizedLY;
  }
}

void InputHandler::GenerateRandomInput(XINPUT_GAMEPAD &input)
{
	int choice;

	choice = rand() % ButtonCount;

	if (choice == BUTTONS_BACK)
	{
		// skip the close button
		while (choice == BUTTONS_BACK)
		{
			choice = rand() % ButtonCount;
		}
	}

	input.wButtons = XInputDefines[choice];
}

void InputHandler::UninitializeAnyPlayback()
{
  if (*playback.enabled_)
    playback.UninitializePlayback();
}
void InputHandler::StopAnyRecording()
{
  if (*recording.enabled_)
    recording.EndRecording();
}

void InputHandler::InitializeAnyPlayback(std::string levelname)
{
  if (*playback.enabled_)
    playback.InitializePlayback(levelname + "Playback.json");
}

void InputHandler::StartAnyRecording(std::string levelname)
{
  if (*recording.enabled_)
    recording.InitializeRecording(levelname);
}
