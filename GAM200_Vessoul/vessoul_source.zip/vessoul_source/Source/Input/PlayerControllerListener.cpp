/****************************************************************************/
/*!
\author Steven Gallwas(Primary) and Henry Morgan
\par    email: s.gallwas\@digipen.edu
\par    Course: GAM 200
\brief  
    This file contains the implementation for the base messaging system.
    -Henry (me) tweaked/adapted some things to add this to PlayerController.

Copyright: All content @ 2014 DigiPen (USA) Corporation, all rights reserved.

*/
/****************************************************************************/
#include "Precompiled.h"
#include "Engine.h"
#include "Physics\rigidbody.h"
#include "DebugMessages.h"
#include "FactoryAccess.h"
#include "SpriteRenderer.h"
#include "PlayerControllerListener.h"
#include "PlayerController.h"
#include "GameStateManager.h"
#include "MenuController.h"
#include "SoundEmitter.h"

/*************************************************************************/
/*!
  \brief
    Updates the current state of a given button for all controllers.
    Called in the update function
  
  \param ButtonType
    the type of button to check.
  
*/
/*************************************************************************/

PlayerControllerListener::PlayerControllerListener(IEntity *playerObj, PlayerController *parent, int ControllerNum) :
  playerController(parent), controllerNum(ControllerNum), player(playerObj)
{
}

void PlayerControllerListener::Initialize()
{
  PlayerBody = reinterpret_cast<RigidBody *>(player->GetComponent(CT_Body));
  PlayerSprite = reinterpret_cast<SpriteRenderer *>(player->GetComponent(CT_SpriteRenderer));
  PlayerTransform = reinterpret_cast<Transform *>(player->GetComponent(CT_TransformComponent));
}


void PlayerControllerListener::OnMessageRecieved(Message * SentMessage)
{
  if (!SentMessage)
  {
    MessageBox(NULL, "PlayerControllerListener got a null message? What?", NULL, NULL);
    return;
  }
  InputMessage *GivenInput = reinterpret_cast<InputMessage *>(SentMessage);
	if (GivenInput->Controller_Num != controllerNum)
		return;

    if(gGameStatePaused == true)
  {
    return;
  }

  switch(GivenInput->TriggeredKey)
  {
	case BUTTONS_A:
    if (GivenInput->KeyPressed == true)
    {
          ((SoundEmitter*)player->GetComponent(CT_SoundEmitter))->SetVolume(1.0f, "player_jump");
          ((SoundEmitter*)player->GetComponent(CT_SoundEmitter))->StopEvent("player_jump");
          ((SoundEmitter*)player->GetComponent(CT_SoundEmitter))->PlayEvent("player_jump");

          if (this->playerController->getJumpState() == JumpStates::JS_Grounded)
          {
              PlayerSprite->GetCurrentSprite()->PauseAt(4);
          }

          playerController->PressJump();
    }
    
    else if (GivenInput->KeyReleased == true)
    {
        PlayerSprite->GetCurrentSprite()->PauseAt(5);
        playerController->ReleaseJump();
    }

    break;

      
  case BUTTONS_X:
      if (GivenInput->KeyPressed)
      {
          GlobalSystem->SendActivate(this->player->GetTransform()->GetPosition());
      }

		break;

	case BUTTONS_B:			

		break;
      
	case BUTTONS_Y:
    break;

  case BUTTONS_RIGHT_SHOULDER:
      //this->ParentObject->GetTransform()->GetRotation().z -= 2 * GivenInput->time;
    break;

  case BUTTONS_LEFT_SHOULDER:
      //this->ParentObject->GetTransform()->GetRotation().z += 2 * GivenInput->time;
    break;
    
  case BUTTONS_BACK:
      PostQuitMessage(0);
    break;
    
  case BUTTONS_START:
     if(gGameStateCurr == GS_LEVEL)
    {
      if (gGameStatePaused)
      {
        MenuMessage msg_pause_deactivate(NULL);
        msg_pause_deactivate.Type = DeactivatePause;

        GlobalSystem->MyDispatchMessage(&msg_pause_deactivate);
        gGameStatePaused = false;
        ENGINE->m_Sound->ResumeAll();
      }
              
      else
      {
          MenuMessage msg1(NULL);
          msg1.Type = UPDATE_POSITION;
          msg1.newPosition = ENGINE->m_Graphics->GetMainCamera()->GetPosition();
          GlobalSystem->MyDispatchMessage(&msg1);

          MenuMessage msg_pause_activate(NULL);
          msg_pause_activate.Type = ActivatePause;

          GlobalSystem->MyDispatchMessage(&msg_pause_activate);
          //ShowPauseMenu();
          gGameStatePaused = true;
          ENGINE->m_Sound->PauseAll();
      }
    }

    break;
    
  case DPAD_LEFT:
    //LEFT / -1.0f

    //PlayerBody->velocity.x -= 2.5f * GivenInput->time;

    //if (PlayerBody->velocity.x <= -10.0f)
    //{
    //  PlayerBody->velocity.x = -10.0f;
    //}

      if (this->playerController->getJumpState() == JumpStates::JS_Grounded || this->playerController->getJumpState() == JumpStates::JS_PLATFORM)
      {
          PlayerSprite->GetCurrentSprite()->Set_Paused(false);

        if(this->playerController->WalkTimer > 0.4 && this->playerController->getJumpTimer() < BIT_MORE_THAN_ONE_FRAME)
        {
          ((SoundEmitter*)player->GetComponent(CT_SoundEmitter))->StopEvent("player_footsteps");
          ((SoundEmitter*)player->GetComponent(CT_SoundEmitter))->PlayEvent("player_footsteps");
          this->playerController->WalkTimer = 0.0f;
        }
      }

      if (GivenInput->KeyPressed == true || GivenInput->KeyDown == true)
      {
        PlayerSprite->ChangeState("running");
        PlayerBody->velocity.x = -(*playerController->playerRunSpeed);
        
        //Make the player face left
        if (PlayerTransform->GetScale().x > 0)
        {
          PlayerTransform->GetScale().x *= -1.0f;
        }
      }

      if (GivenInput->KeyReleased == true)
      {
        PlayerSprite->ChangeState("idle");
        PlayerBody->velocity.x = 0.0f;
      }
    
      break;

    
  case DPAD_RIGHT:

    //PlayerBody->velocity.x += 2.5f * GivenInput->time;

   // if (PlayerBody->velocity.x >= 10.0f)
   // {
   //   PlayerBody->velocity.x = 10.0f;
   // }

          // if the player is grounded and the player is pressing right, play move sound effect
      if (this->playerController->getJumpState() == JumpStates::JS_Grounded || this->playerController->getJumpState() == JumpStates::JS_PLATFORM)
      {
         PlayerSprite->GetCurrentSprite()->Set_Paused(false);

        if (this->playerController->WalkTimer > 0.4 && this->playerController->getJumpTimer() < BIT_MORE_THAN_ONE_FRAME)
        {
          ((SoundEmitter*)player->GetComponent(CT_SoundEmitter))->StopEvent("player_footsteps");
          ((SoundEmitter*)player->GetComponent(CT_SoundEmitter))->PlayEvent("player_footsteps");
          this->playerController->WalkTimer = 0.0f;
        }
      }

      // change sprite and flip sprite if necessary
      if (GivenInput->KeyPressed == true || GivenInput->KeyDown == true)
      {
        PlayerSprite->ChangeState("running");
        PlayerBody->velocity.x = *playerController->playerRunSpeed;
        
        if (PlayerTransform->GetScale().x < 0)
        {
          //Face the player right
          PlayerTransform->GetScale().x *= -1.0f; 
        }
      }

      // revert changes when the key is released
      if (GivenInput->KeyReleased == true)
      {
        PlayerSprite->ChangeState("idle");
        PlayerBody->velocity.x = 0.0f;
      }
      
      break;

    
  case DPAD_UP:
    //this->ParentObject->GetTransform()->GetPosition().y += 15 * GivenInput->time;
    break;
    
  case DPAD_DOWN:
		//PlayerBody->velocity.y -= 2.5f * GivenInput->time;
    //this->ParentObject->GetTransform()->GetPosition().y -= 15 * GivenInput->time;
    break;
    
  case LEFT_STICK:
		break;
    
  case RIGHT_STICK:
    break;
  }

}