/****************************************************************************/
/*!
\author Esteban Maldonado
\par    email: esteban.maldonado@digipen.edu
\par    Course: GAM 200
\brief

Class interface for the camera component

Copyright: All content @ 2014 DigiPen (USA) Corporation, all rights reserved.

*/
/****************************************************************************/
#pragma once 

//#include <DirectXMath.h>
#include "Precompiled.h" //<d3d9.h>, <d3dx9.h>, <d3d9types.h>
#include "Core\Transform.h"

//using DirectX::XMVECTOR;
//using DirectX::XMMATRIX;

class Camera : public IComponent
{
public:
  Camera(IEntity* Owner);
  ~Camera()  override;

  //Inherited Methods
  bool Initialize() override;
  void Update(float dt) override;
  void Release() override;

  //Setters
	void SetPosition(float x, float y, float z);
  void SetPosition(Vector3 pos);

	void SetRotation(float x, float y, float z);
  void SetRotation(Vector3 rot);

  void SetZnear(float z);
  void SetZfar(float z);
  void Set_Width_Height(float w, float h);

  void SetBackColor(D3DCOLOR color);

  //Getters
  void GetViewMatrix(D3DXMATRIX& viewMatrix);
  void GetProjMatrix(D3DXMATRIX& projMatrix);

  float GetZnear();
  float GetZfar();

  float GetAspectRatio();
  float GetWidth();
  float GetHeight();

  D3DCOLOR GetBackColor();

  Vector3& GetPosition();
  Vector3& GetRotation();

  Camera& operator=(const Camera& cam);

private:
  void AlignToNearestPixel();

	D3DXMATRIX m_viewMatrix;
  D3DXMATRIX m_projMatrix;
	Vector3 position;
	Vector3 rotation;

  float z_near;
  float z_far;

  float view_angle;
  float width;
  float height;
  D3DCOLOR background_color;
  
};