/****************************************************************************/
/*!
\author Esteban Maldonado
\par    email: esteban.maldonado@digipen.edu
\par    Course: GAM 200
\brief

The basic particle object for the particle emitter.

Copyright: All content @ 2014 DigiPen (USA) Corporation, all rights reserved.

*/
/****************************************************************************/
#pragma once
#include"Vertices.h"

using namespace::d3dVertex;

class Particle
{
public:
  Particle(Vector3 initial_pos = Vector3(), float lifespan = 1.0f);
  ~Particle();

  void render_particle(IDirect3DDevice9* device, IDirect3DVertexBuffer9** t_buffer, 
    IDirect3DTexture9* texture, D3DCOLOR color, D3DCOLOR end_color);
  void set_particle(IDirect3DDevice9* device, float radius, float end_radius/*, float camx, float camy, float camz*/);
  void run_particle(float dt, float p_lifetime, Vector3 pos, float ang_1 = 90.0f, 
    float ang_2 = 90.0f, float spd1 = 1.0f, float spd2 = 4.0f, float acc1 = 1.0f, float acc2 = 20.0f);
  void reset_particle(Vector3 pos, float ang_1 = 90.0f, float ang_2 = 90.0f, float spd1 = 1.0f, 
    float spd2 = 4.0f, float acc1 = 1.0f, float acc2 = 20.0f);

  bool active;

  D3DXVECTOR3 position;
  D3DXVECTOR3 initial_position;
  D3DXVECTOR3 velocity;
  D3DXVECTOR3 acceleration;
  float mass;
  //float radius;
  float lifespan;
  float current_life;
  D3DXMATRIX matRotateX;
  D3DXMATRIX matRotateY;
  D3DXMATRIX matRotateZ;
  D3DCOLOR color;
  D3DCOLOR end_color;

  // this function generates random float values
  float random_number(float low, float high)
  {
    return low + ((float)((float)rand() / (float)RAND_MAX) * (float)((high)-(low)));
  }
};