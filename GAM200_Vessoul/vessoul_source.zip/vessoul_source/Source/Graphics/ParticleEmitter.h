/****************************************************************************/
/*!
\author Esteban Maldonado
\par    email: esteban.maldonado@digipen.edu
\par    Course: GAM 200
\brief

Class interface for the Particle Emitter component

Copyright: All content @ 2014 DigiPen (USA) Corporation, all rights reserved.

*/
/****************************************************************************/
#pragma once
#include"Precompiled.h"
#include"Particle.h"

#define MAX_PARTICLE_COUNT 1000
#define PE_LOOPING 0

//Forward Declarations
class ParticleEmitter;

typedef std::vector<ParticleEmitter*> ParticleEmitVector;
typedef ParticleEmitVector::iterator PartEmitVecIter;

class ParticleEmitter : public IComponent
{
public:
  ParticleEmitter(GameObject Owner, IDirect3DDevice9* device, 
    unsigned int particle_count = MAX_PARTICLE_COUNT/2, char* t_name = NULL,
    D3DCOLOR color = d3dColors::White, D3DCOLOR end_color = d3dColors::White);
  ~ParticleEmitter();

  //Inherited methods
  bool Initialize() override;
  void Update(float dt) override;
  void Release() override;

  //Methods
  void Render(IDirect3DDevice9* device);
  
  //Getters
  unsigned int& GetParticleCount();

  //Setters
  void SetParticleCount(unsigned int pc);

  Particle particles[MAX_PARTICLE_COUNT];

  static IDirect3DVertexBuffer9* v_buffer;
  static IDirect3DIndexBuffer9* i_buffer;

  //lifepspan for the paarticle emitter itself
  float current_PE_lifespan;
  float PE_lifespan;

  //particle scale
  float radius;
  float end_radius;

  //start delay for the PE
  float start_delay;

  //lifetime of each particle
  float particle_lifetime;

  //Particles will spawn anywhere between these angles.
  float angle_1, angle_2;
  float speed_1, speed_2;
  float acceleration_1, acceleration_2;

  //gravity for each particle
  float gravity;

  //Intial and end color for each particle
  D3DCOLOR color;
  D3DCOLOR end_color;
  bool blend_colors;

  unsigned int particle_count;

  float x_diff_from_owner;
  float y_diff_from_owner;

private:
  IDirect3DDevice9* device;

  char* texture_name;
  IDirect3DTexture9* texture;
  IDirect3DVertexBuffer9* t_buffer;
};