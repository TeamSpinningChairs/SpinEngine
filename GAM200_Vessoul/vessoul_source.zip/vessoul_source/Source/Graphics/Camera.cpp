/****************************************************************************/
/*!
\author Esteban Maldonado
\par    email: esteban.maldonado@digipen.edu
\par    Course: GAM 200
\brief

Class interface for the camera component

Copyright: All content @ 2014 DigiPen (USA) Corporation, all rights reserved.

*/
/****************************************************************************/
#include "Precompiled.h"
#include "Camera.h"

#define PIXELS_PER_UNIT 64.0f

Camera::Camera(IEntity* Owner) : IComponent( CT_CameraComponent, Owner), 
position(Vector3()), rotation(Vector3()), z_near(0), z_far(5000.0f), view_angle(D3DX_PI / 4.0f),
width(800), height(600), background_color(d3dColors::Black)
{
  if (Owner)
  {
    position.x = Owner->GetTransform()->GetPosition().x;
    position.y = Owner->GetTransform()->GetPosition().y;
    position.z = Owner->GetTransform()->GetPosition().z - 28.0f; //28 is close on the x-axis

    rotation = Owner->GetTransform()->GetRotation();
  }
}

Camera::~Camera()
{

}

void Camera::SetPosition(float x, float y, float z)
{
  position.x = x;
  position.y = y;
  position.z = z;
}

void Camera::SetPosition(Vector3 pos)
{
  position = pos;
}

void Camera::SetRotation(float x, float y, float z)
{
	rotation.x = x;
	rotation.y = y;
	rotation.z = z;
}

void Camera::SetRotation(Vector3 rot)
{
  rotation = rot;
}

void Camera::GetViewMatrix(D3DXMATRIX& viewMatrix)
{
  D3DXVECTOR3 up;
  D3DXVECTOR3 lookAt;
  float radians;

  //If the camera has an owner then follow it on X and Y
  if (Owner)
  {
    position.x = Owner->GetTransform()->GetPosition().x;
    position.y = Owner->GetTransform()->GetPosition().y;
    AlignToNearestPixel();

    rotation = Owner->GetTransform()->GetRotation();
  }

  // Setup the vector that points upwards.
  up.x = 0.0f;//x
  up.y = 1.0f;//y
  up.z = 0.0f;//z

  // Calculate the rotation in radians.
  radians = rotation.y * 0.0174532925f;

  // Setup where the camera is looking.
  lookAt.x = sinf(radians) + position.x;
  lookAt.y = position.y;
  lookAt.z = cosf(radians) + position.z;

  // Create the view matrix from the three vectors.
  D3DXVECTOR3 vm = D3DXVECTOR3(position.x, position.y, position.z);
  D3DXMatrixLookAtLH(&m_viewMatrix, &vm,
    &lookAt, &up);

	viewMatrix = m_viewMatrix;
}

void Camera::GetProjMatrix(D3DXMATRIX& projMatrix)
{
  D3DXMatrixPerspectiveFovLH(&m_projMatrix, view_angle, width / height, z_near, z_far);
  //D3DXMatrixOrthoLH(&m_projMatrix, 1024, 768, 0.0f, 5000.0f);
  projMatrix = m_projMatrix;
}

bool Camera::Initialize()
{
  return true;
}

void Camera::Update(float dt)
{
}

Camera& Camera::operator=(const Camera& cam)
{
  position = cam.position;
  rotation = cam.rotation;

  z_near = cam.z_near;
  z_far = cam.z_far;

  width = cam.width;
  height = cam.height;

  return *this;
}

void Camera::SetZnear(float z)
{
  z_near = z;
}

void Camera::SetZfar(float z)
{
  z_far = z;
}

float Camera::GetZnear()
{
  return z_near;
}

float Camera::GetZfar()
{
  return z_far;
}

float Camera::GetAspectRatio()
{
  return width / height;
}

float Camera::GetWidth()
{
  return width;
}

float Camera::GetHeight()
{
  return height;
}

Vector3& Camera::GetRotation()
{
  return rotation;
}

Vector3& Camera::GetPosition()
{
  return position;
}

D3DCOLOR Camera::GetBackColor()
{
  return background_color;
}

void Camera::SetBackColor(D3DCOLOR color)
{
  background_color = color;
}

void Camera::Set_Width_Height(float w, float h)
{
  width = w;
  height = h;
}

void Camera::Release()
{
}

void Camera::AlignToNearestPixel()
{
  //position.x = MathF::Round(position.x * PIXELS_PER_UNIT) / PIXELS_PER_UNIT;
  //position.y = MathF::Round(position.y * PIXELS_PER_UNIT) / PIXELS_PER_UNIT;
}