/****************************************************************************/
/*!
\author Esteban Maldonado
\par    email: esteban.maldonado@digipen.edu
\par    Course: GAM 200
\brief

The basic particle object for the particle emitter.

Copyright: All content @ 2014 DigiPen (USA) Corporation, all rights reserved.

*/
/****************************************************************************/
#include"Precompiled.h"
#include "Particle.h"

//const DWORD CUSTOMVERTEX::FVF = CUSTOMFVF;

Particle::Particle(Vector3 initial_pos, float lifespan) : current_life(0),
  lifespan(lifespan), position(D3DXVECTOR3(initial_pos.x, initial_pos.y, initial_pos.z)),
  initial_position(D3DXVECTOR3(initial_pos.x, initial_pos.y, initial_pos.z)), active(false)
{
}

Particle::~Particle()
{
}

void Particle::render_particle(IDirect3DDevice9* device, IDirect3DVertexBuffer9** t_buffer, 
  IDirect3DTexture9* texture, D3DCOLOR color, D3DCOLOR end_color)
{
  //set_particle(device);
  if (color != end_color)
  {
    D3DCOLOR new_color;
    new_color = color + ( static_cast<D3DCOLOR>( static_cast<float>(end_color - color) * (current_life / lifespan) ) );

    VOID* pVerts;
    //LOCK THE MEMORY TO MAKE SURE DATA IS PASSED THROUGH
    (*t_buffer)->Lock(0, sizeof(d3dVertex::CUSTOMVERTEX) * 4/*NUM_VERTS*/, (void**)&pVerts, 0);
    d3dVertex::CUSTOMVERTEX* temp = reinterpret_cast<d3dVertex::CUSTOMVERTEX*>(pVerts);

    temp[0].color = temp[1].color = temp[2].color = temp[3].color = new_color;

    (*t_buffer)->Unlock();
  }

  device->SetStreamSource(0, (*t_buffer), 0, sizeof(CUSTOMVERTEX));
  
  if (texture)
  {
    device->SetTexture(0, texture);
  }
  else
  {
    device->SetTexture(0, NULL);
  }

  device->DrawPrimitive(/*D3DPT_LINESTRIP*/ D3DPT_TRIANGLESTRIP, 0, 2);
}

void Particle::set_particle(IDirect3DDevice9* device, float radius, float end_radius /*float camx, float camy, float camz*/)
{
  // Before setting the world transform, do the intense mathematics!
  // a. Calculate the Differences
  //static float difx, dify, difz;
  //difx = camx - position.x;
  //dify = camy - position.y;
  //difz = camz - position.z;

  //// b. Calculate the Distances
  //static float FlatDist, TotalDist;
  //FlatDist = sqrt(difx * difx + difz * difz);
  //TotalDist = sqrt(FlatDist * FlatDist + dify * dify);

  // c. Y Rotation
  D3DXMatrixIdentity(&matRotateY);
  //matRotateY._11 = matRotateY._33 = difz / FlatDist;    // cosY
  //matRotateY._31 = difx / FlatDist;    // sinY
  //matRotateY._13 = -matRotateY._31;    // -sinY

  // d. X Rotation
  D3DXMatrixIdentity(&matRotateX);
  //matRotateX._22 = matRotateX._33 = FlatDist / TotalDist;    // cosX
  //matRotateX._32 = dify / TotalDist;    // sinX
  //matRotateX._23 = -matRotateX._32;    // -sinX

  D3DXMatrixRotationZ(&matRotateZ, 0.0f);

  // e. Tranlation
  static D3DXMATRIX matTranslate;
  D3DXMatrixTranslation(&matTranslate, position.x, position.y, position.z);

  // f. Scaling
  static D3DXMATRIX matScale;
  D3DXMatrixIdentity(&matScale);
  
  if (end_radius != radius)//abs(end_radius - radius) > 0.001)
  {
    matScale._11 = matScale._22 = matScale._33 = radius + ((end_radius - radius) * (current_life / lifespan));
  }

  else
  {
    matScale._11 = matScale._22 = matScale._33 = radius;
  }

  // Now build the world matrix and set it
  device->SetTransform(D3DTS_WORLD, &(matScale * matRotateX * matRotateY * matRotateZ * matTranslate));
}

void Particle::run_particle(float dt, float p_lifetime, Vector3 pos, float ang_1,
  float ang_2, float spd1, float spd2, float acc1,float acc2)
{
  // handle lifespan
  current_life += dt;
  if (current_life > p_lifetime)
  {
    reset_particle(pos, ang_1, ang_2,spd1,spd2,acc1,acc2);
    return;
  }

  velocity += acceleration * dt;
  position += velocity * dt;
}

void Particle::reset_particle(Vector3 pos, float ang_1 , float ang_2 , float spd1 , float spd2, float acc1 , float acc2)
{
  active = false;
  position.x = pos.x;
  position.y = pos.y;
  position.z = pos.z;

  float angle_new = random_number(std::min(ang_1, ang_2), std::max(ang_1, ang_2));
  float speed = random_number(std::min(spd1, spd2), std::max(spd1, spd2));
  float acc = random_number(std::min(acc1, acc2), std::max(acc1, acc2));

  velocity.x = cos((angle_new / 180.0f) * PI) * speed;
  velocity.y = sin((angle_new / 180.0f) * PI);// random_number(-2.0f, 2.0f);
  velocity.z = 0.0f;

  acceleration.x = cos((angle_new / 180.0f) * PI) * acc;
  acceleration.y = sin((angle_new / 180.0f) * PI) * acc;
  acceleration.z = 0.0f;//random_number(-15.0f, 25.0f);
  
  current_life = 0.0f;
}
