/****************************************************************************/
/*!
\author Henry Morgan, Steven Galwas
\par    email: henry.morgan@digipen.edu
\par    Course: GAM 200
\brief

Manages player controls. Contains a KeyboardListener and ControllerListener
that directly affect horizontal velocity and call the jump functions within
this class. This class controls jump and movement states, all options and
settings for double jump, variable jump height, jump speed, etc... as well
as maximum fall speed and all OnCollision events that should affect the
player object.

(Steven's code/contributions are throughout, but some parts are noted
specifically.)

Copyright: All content @ 2014 DigiPen (USA) Corporation, all rights reserved.

*/
/****************************************************************************/
#include "Precompiled.h"
#include "PlayerController.h"
#include "Settings.h"
#include "NewMessageSystem.h"
#include "DebugMessages.h"

//Note: Gonna need a way to assign unique controller numbers once we have multiple players.
//Do this in the input system/whatever


#define PIXELS_PER_UNIT 64.0f
#define TIME_TO_DIE 1.5f

PlayerController::PlayerController(GameObject Parent, int ControllerNum) : parent(Parent),
IComponent(Component_Type::CT_Player_Controller, Parent),
CollisionDelegate(Parent),
controller(new PlayerControllerListener(Parent, this, ControllerNum)),
keyboard(new PlayerKeyboardListener(Parent, this)),
myJumpState(JS_Grounded), jumpCount(0), jumpTimer(0), playerIsAlive(true), deathTimer(0)
{
  float *temp = NULL;
  GlobalSettings->GetFloatValue("___ PLAYER MOVEMENT SETTINGS ___", temp, false);
  GlobalSettings->GetFloatValue("Player Run Speed", playerRunSpeed, true);
  GlobalSettings->GetFloatValue("Player Jump Velocity", playerJumpVelocity, true);
  GlobalSettings->GetBoolValue("Double Jump Enabled", doubleJumpEnabled, true);
  GlobalSettings->GetBoolValue("Variable Jump Height Enabled", variableJumpHeightEnabled, true);
  GlobalSettings->GetFloatValue("Variable Jump Time", variableJumpTime, true);
  GlobalSettings->GetFloatValue("Variable Jump Power", variableJumpPower, true);
  GlobalSettings->GetFloatValue("Time To Jump After Leaving Ground", timeToJumpAfterLeftGround, true);
  GlobalSettings->GetFloatValue("Max Downwards Velocity", maxDownwardsVelocity, true);

  Platform = NULL;
  WalkTimer = 0.0f;
  PreviousPlatformPosition.x = 0;
  PreviousPlatformPosition.y = 0;
  PreviousPlatformPosition.z = 0;
}

bool PlayerController::Initialize()
{
  GlobalSystem->RegisterListener(MessageTypes::MESSAGE_INPUT, controller);
  GlobalSystem->RegisterListener(MessageTypes::MESSAGE_KEYBOARD, keyboard);
  playerTileCollision = reinterpret_cast<TileMapCollision*>(parent->GetComponent(CT_TileMapCollider));
  playerBody = reinterpret_cast<RigidBody *>(parent->GetComponent(CT_Body));
  playerSpriteRend = reinterpret_cast<SpriteRenderer *>(parent->GetComponent(CT_SpriteRenderer));
  keyboard->Initialize();
  controller->Initialize();

  InitializeCollisionCallback();
  //playerBody->AddTriggerCallback();
  return true;
}

PlayerController::~PlayerController()
{
  GlobalSystem->UnregisterListener(MessageTypes::MESSAGE_INPUT, keyboard);
  GlobalSystem->UnregisterListener(MessageTypes::MESSAGE_KEYBOARD, controller);
}

void PlayerController::Update(float dt)
{
  //When player dies, stop for 2 seconds and then reload
  if (!playerIsAlive)
  {
    deathTimer += dt;
    if (deathTimer > TIME_TO_DIE)
    {
      gGameStateCurr = GS_LOAD;
    }
    return;
  }

  jumpTimer += dt;
  WalkTimer += dt;

  //Cap player's downwards velocity
  if (playerBody->velocity.y < -(*maxDownwardsVelocity))
  {
    playerBody->velocity.y = -(*maxDownwardsVelocity);
    //playerBody->acceleration.y = 0;
  }
  
  //Keep the timer at 0 while we're grounded
  if (myJumpState == JS_Grounded)
  {
    if (playerTileCollision->BottomIsColliding())
      jumpTimer = 0;

    return;
  }

  /* Written by Steven Gallwas prevents player from falling off of platforms*/
  if (myJumpState == JS_PLATFORM)
  {
      if (Platform != NULL)
      {

        float PlayerCheckX = abs(Owner->GetTransform()->GetPosition().x - Platform->GetTransform()->GetPosition().x);
        float PlayerCheckY = abs(Owner->GetTransform()->GetPosition().y - Platform->GetTransform()->GetPosition().y);
       

        if(PlayerCheckX < 1.0 && PlayerCheckY < 2.0)
        {
          // calculate how far the platform has moved
          float XDiff = Platform->GetTransform()->GetPosition().x - PreviousPlatformPosition.x;
          float YDiff = Platform->GetTransform()->GetPosition().y - PreviousPlatformPosition.y;


          playerBody->position.x += XDiff;
          Owner->GetTransform()->GetPosition().x += XDiff;

          float PlatformYVel = ((RigidBody*)Platform->GetComponent(CT_Body))->velocity.y;
          float PlatformXVel = ((RigidBody*)Platform->GetComponent(CT_Body))->velocity.x;

          playerBody->velocity.y = PlatformYVel;
         
          if(YDiff <= 0)
          {
            playerBody->position.y += YDiff;
            Owner->GetTransform()->GetPosition().y += YDiff;
          }
            // move the player with the platform
          PreviousPlatformPosition = Platform->GetTransform()->GetPosition();
        
        }
        
        else
        {
          Platform = NULL;

           //myJumpState = JS_Grounded;
        }

      }
  }// end of Steven Code 

  //We're jumping:
  
  //Reset us when we hit the ground
  if (playerTileCollision->BottomIsColliding() && jumpTimer > BIT_MORE_THAN_ONE_FRAME)
  {
    jumpCount = 0;
    jumpTimer = 0;
    myJumpState = JS_Grounded;
    return;
  }
  //Keep our variable-height jump going up to the max height
  if (myJumpState == JS_VariableJumping)
  {
    playerBody->velocity.y = *playerJumpVelocity * (*variableJumpPower);

    //At max height, stop our variable jump.
    if (jumpTimer > *variableJumpTime)
    {
      jumpTimer = 0;
      myJumpState = JS_Jumping;
    }
      
  }

  //AlignToNearestPixel();
  
}

void PlayerController::Release()
{

}

//Only ever called by the controllers:
void PlayerController::PressJump()
{
  if (!playerIsAlive)
    return;

  //Possible options:
  //A: If we're not jumping, and we're on solid ground or left solid ground within a few frames,
  //   apply jump velocity and change our state
    if ((myJumpState == JS_Grounded || myJumpState == JS_PLATFORM) && (playerTileCollision->BottomIsColliding() || jumpTimer < *timeToJumpAfterLeftGround))
  {
    if (*variableJumpHeightEnabled)
      myJumpState = JS_VariableJumping;
    else
      myJumpState = JS_Jumping;

    if (*variableJumpHeightEnabled)
      playerBody->velocity.y = *playerJumpVelocity * (*variableJumpPower);
    else
      playerBody->velocity.y = *playerJumpVelocity;

    jumpTimer = 0.0f;
    ++jumpCount;
    return;
  }
  //B: If we're jumping, and double-jump is enabled, apply jump velocity
  if (myJumpState == JS_Jumping && *doubleJumpEnabled && jumpCount < 2)
  {
    playerBody->velocity.y = *playerJumpVelocity;
    ++jumpCount;
    if (*variableJumpHeightEnabled)
      myJumpState = JS_VariableJumping;
    return;
  }
}

void PlayerController::ReleaseJump()
{
  //A: If we have variable jump height, switch us to the upward state
  if (*variableJumpHeightEnabled && myJumpState == JS_VariableJumping)
  {
    myJumpState = JS_Jumping;
    playerBody->velocity.y = *playerJumpVelocity;
  }
}

void PlayerController::OnCollision(GameObject otherObject)
{
    if ((otherObject->GetComponent(CT_MOVPLATFORM)) && jumpTimer > BIT_MORE_THAN_ONE_FRAME)
    {
        myJumpState = JS_PLATFORM;
        jumpTimer = 0;
        Platform = otherObject;
        PreviousPlatformPosition = otherObject->GetTransform()->GetPosition();
    }

    if ((otherObject->GetComponent(CT_SPAWN_BLOCK) || otherObject->GetComponent(CT_DESTROY_ON_ACTIVATE))  && jumpTimer > BIT_MORE_THAN_ONE_FRAME)
    {
        myJumpState = JS_Grounded;
        jumpTimer = 0;
    }
    
    //If we hit a "kill the player" object, reload at last checkpoint
    //(after 2 seconds- see the beginning of Update)
    if (otherObject->GetComponent(CT_KILLPLAYER))
    {
      KillPlayer();
    }

}


  int PlayerController::getJumpState(void)
  {
    return myJumpState;
  }

  void PlayerController::AlignToNearestPixel()
  {
    //playerBody->position.x = MathF::Round(playerBody->position.x * PIXELS_PER_UNIT) / PIXELS_PER_UNIT;
   // playerBody->position.y = MathF::Round(playerBody->position.y * PIXELS_PER_UNIT) / PIXELS_PER_UNIT;
    
    //Owner->GetTransform()->GetPosition().x = playerBody->position.x;
   // Owner->GetTransform()->GetPosition().y = playerBody->position.y;

  }

  float PlayerController::getJumpTimer(void)
  {
      return jumpTimer;
  }


  void PlayerController::KillPlayer()
  {
    playerIsAlive = false;
    parent->SetInVisible();
  }