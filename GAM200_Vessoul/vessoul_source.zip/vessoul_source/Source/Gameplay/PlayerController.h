/****************************************************************************/
/*!
\author Henry Morgan, Steven Galwas
\par    email: henry.morgan@digipen.edu
\par    Course: GAM 200
\brief

Manages player controls. Contains a KeyboardListener and ControllerListener
that directly affect horizontal velocity and call the jump functions within
this class. This class controls jump and movement states, all options and
settings for double jump, variable jump height, jump speed, etc... as well
as maximum fall speed and all OnCollision events that should affect the
player object.

(Steven's code/contributions are throughout, but some parts are noted
specifically.)

Copyright: All content @ 2014 DigiPen (USA) Corporation, all rights reserved.

*/
/****************************************************************************/
#pragma once

#include "IComponent.h"
#include "IEntity.h"
#include "rigidbody.h"
#include "SpriteRenderer.h"
#include "PlayerControllerListener.h"
#include "PlayerKeyboardListener.h"
#include "collision_tilemap.h"

#define BIT_MORE_THAN_ONE_FRAME 0.02f

//PlayerKeyboardListeners and/or PlayerControllerListeners will call the public functions in here.
//This should access the player object's rigidbody, sprite, etc...

//Not all that much will happen in Update, this is mostly a common point of reference
//for our Keyboard and Controller inputs.
//Changes made to the rigidbody, etc... here can be stopped later on by tilemap collision
//or box colliders. @Check with Judy to see if there's anything in place to guarantee
//rigidbodies are updated AFTER any boxcollider they have.

//Potentially: Have the listeners affect our acceleration/jump rigidbodies.


enum JumpStates //Used in Jump()
{
  JS_Grounded, //Or falling without having jumped
  JS_VariableJumping, //If we have variable jump height enabled, this is the initial "button held down" jump
  JS_Jumping,
  JS_PLATFORM
};

class PlayerController : public IComponent, public CollisionDelegate
{
public:

	PlayerController(GameObject Parent, int ControllerNum);
  ~PlayerController();

	bool Initialize();
	
	void Update(float dt);
	
	void Release();

  //Called by imput listeners:
  void PressJump();
  void ReleaseJump();

  //Can be modified, but should only be modified by tweak bar at runtime
  //(unless we introduce mechanics to slow the player down, or something)
  float *playerRunSpeed;
  float *playerJumpVelocity;

  int getJumpState(void);
  float WalkTimer;
  float getJumpTimer(void);

  void KillPlayer();

private:
  Vector3 PreviousPlatformPosition;
  GameObject Platform;
	RigidBody *playerBody;
  SpriteRenderer *playerSpriteRend;
  TileMapCollision *playerTileCollision;

  void AlignToNearestPixel();

  //Both of these have listeners that register with the messaging system.
  PlayerControllerListener *const controller;
  PlayerKeyboardListener *const keyboard;

  GameObject parent;

  JumpStates myJumpState;

  bool *doubleJumpEnabled;
  bool *variableJumpHeightEnabled;
  unsigned jumpCount;
  float jumpTimer;
  float *variableJumpTime;
  float *variableJumpPower;
  float *maxDownwardsVelocity;

  float airbornTimer;
  float *timeToJumpAfterLeftGround;
  void OnCollision(GameObject) override;

  bool playerIsAlive;
  float deathTimer;
};
