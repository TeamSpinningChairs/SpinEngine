/****************************************************************************/
/*!
\author Henry Morgan
\par    email: henry.morgan@digipen.edu
\par    Course: GAM 200
\brief

Factory accessor class.

Copyright: All content @ 2014 DigiPen (USA) Corporation, all rights reserved.

*/
/****************************************************************************/
#include "Precompiled.h"
#include "FactoryAccess.h"
#include "Sprite.h" //To create sprites
#include "SpriteRenderer.h" //To create sprite renderers
#include "GraphicsManager.h" //To add sprite renderers to graphics manager
#include "Wall.h"

//We actually set this in Engine.cpp (during engine init), but we need to initialize here.
FactoryAccess *GlobalFactory = nullptr;

FactoryAccess::FactoryAccess(FactoryManager &factorymanager) : factory_(factorymanager)
{
  directXDevice_ = factorymanager.directXDevice_;
}

void FactoryAccess::LoadLevel(std::string levelName)
{
  factory_.LoadLevel(levelName);
}
void FactoryAccess::UnloadLevel()
{
  factory_.UnloadLevel();
}
void FactoryAccess::Initialize()
{
  factory_.Initialize();
}
void FactoryAccess::AddGameObject(GameObject ent)
{
  factory_.AddGameObject(ent);
}
void FactoryAccess::RemoveGameObject(EntityId id)
{
  factory_.RemoveGameObject(id);
}

int FactoryAccess::AddTile(std::string spritename, int position, int tilemapWidth)
{
  factory_.CreateBasicTile(factory_.defaults.GetIDFromSpriteName(spritename.c_str()), position, tilemapWidth, HALF_TILE_WIDTH);
  return factory_.m_TotalObjectCount - 1; //we subtract 1 because the count is incremented after the tile is created
}

void FactoryAccess::RemoveTileObject(EntityId id)
{
  factory_.RemoveTileObject(id);
}

IDirect3DDevice9 *FactoryAccess::GetDevice()
{
  return directXDevice_;
}

int FactoryAccess::GetGameObjectCount()
{
	return factory_.GetGameObjectCount(); 
}

GraphicsManager *FactoryAccess::GetGraphicsManager()
{
  return factory_.m_pGraphicsManager;
}

IEntity *FactoryAccess::CreateGameObject(std::string name, std::string spritename, Vector3 pos, D3DCOLOR color, bool is_UI)
{
  IEntity *mem_obj = reinterpret_cast<GameObject>( MemoryManager::Allocate_GameObj() );
  
  IEntity *obj = new (mem_obj)IEntity(factory_.GetGameObjectCount(), pos, 
    Vector3(0, 0, 0), Vector3(1, 1, 0), "default", name.c_str());

  SpriteRenderer *spRend = new SpriteRenderer(obj, directXDevice_, color);
  //spRend->AddSprite(CreateSprite(spritename));
  spRend->AddSprite(CreateSprite(spritename));
  if (is_UI)
    factory_.m_pGraphicsManager->AddUISpriteRend(spRend);
  else
    factory_.m_pGraphicsManager->AddSpriteRend(spRend); 
  
  obj->AddGameComponent(CT_SpriteRenderer, spRend);
  
  factory_.AddGameObject(obj);
  return obj;
}

//Needs to be passed a valid sprite name (I.E. one of the ones we load in)
//Checks in object data, creates a sprite without needing to create a new texture
//(I'm working on art pipeline, ask me about this)
Sprite *FactoryAccess::CreateSprite(std::string spritename)
{
  return factory_.defaults.CreateSprite(factory_.defaults.GetIDFromSpriteName(spritename));
}

//I.E. FactoryManager::TileMapData &data = GetTileMapData();
FactoryManager::TileMapData &FactoryAccess::GetTileMapData()
{
  return factory_.tileMap_;
}


GameObjectUmap &FactoryAccess::GetGameObjectList()
{
  return factory_.m_GameObjectList;
}

IComponent *FactoryAccess::GetWall()
{
  return factory_.GetWall();
}

