/****************************************************************************/
/*!
\author Henry Morgan
\par    email: henry.morgan@digipen.edu
\par    Course: GAM 200
\brief

Factory class (see .cpp for more info)

Copyright: All content @ 2014 DigiPen (USA) Corporation, all rights reserved.

*/
/****************************************************************************/
#pragma once

#include"Utilities\ISystem.h"
#include"Core\IEntity.h"
#include"Factory\Serializer\JSONLoader.h"
#include "Factory\Serializer\DynamicElement.h"
#include "Factory\ObjectData.h"
#include "Factory\LevelData.h"

//forward declaration
class GraphicsManager;
class FactoryAccess;

class FactoryManager : public ISystem
{
  friend class FactoryAccess;

public:
  //Constructor & Destructor
  FactoryManager(GraphicsManager* m_pGraphicsManager);
  ~FactoryManager();
  
  //Generic System Functions
  bool Initialize() override;
  void Update(float dt) override;
  void Shutdown() override;

  //Getters
  std::string GetName();
  GameObjectUmap* GetObjectList();
  unsigned int GetGameObjectCount();

  //Methods
  void AddEmptyGameObject();
  void AddGameObject(GameObject ent);
  void RemoveGameObject(EntityId id);
  void RemoveTileObject(EntityId id);

  //Level & object creation
  void LoadLevel(std::string levelName);
  void UnloadLevel();
  IComponent *GetWall();
  void SetWall(IComponent *wall);
  void ClearEverythingInFactory();
  GameObject FindObjectByName(std::string);

  //Tilemap data
  struct TileMapData
  {
    int width;
    int height;
    int numTiles;
    std::vector<int> *tiles;
    std::vector<int> origTiles;
    std::vector<int> targetTiles;
    std::vector<int> factoryIndeces;

    TileMapData();
  };
  TileMapData tileMap_;

private:
  GameObjectUmap m_GameObjectList;
  //Graphics - related properties'
  GraphicsManager *m_pGraphicsManager;
  //counters that will not ever decrease:
  unsigned int m_TotalObjectCount;
  unsigned int m_DeletedObjectCount;
  //This goes up and down all the time, though!
  unsigned int m_CurrentObjectCount;

  //For giving all game objects access to the wall.
  IComponent *wall_;

  //Here so that FactoryAccess can grab it without knowing what GraphicsManager is
  IDirect3DDevice9 *directXDevice_;

  
  //JSONLoader loader;
  ObjectData defaults; //Will load all prefab properties in constructor.
  LevelData levels; //Will load all paths to level files, but not any level data itself

  bool PopulateLevel(DynamicElement &root);
  //Helpers for PopulateLevel
  void CreateBasicTile(int tileID, int position, int mapWidth, int halfTileWidth);
  void FactoryManager::CreateGameObject(DynamicElement *object);

};
